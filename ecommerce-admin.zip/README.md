# E-commerce + Admin (Express + SQLite + EJS)

## Chạy nhanh
1. Cài Node.js (>=18)
2. Mở terminal, chạy:
   ```bash
   npm install
   node app.js
   ```
3. Mở http://localhost:3000
4. Trang quản trị: http://localhost:3000/admin  
   - Tài khoản mặc định: `admin`  
   - Mật khẩu mặc định: `admin123`

## Tính năng
- Trang sản phẩm, chi tiết, giỏ hàng đơn giản, đặt hàng (chưa tích hợp thanh toán).
- Trang quản trị: đăng nhập, quản lý sản phẩm (thêm/sửa/xoá, upload ảnh), xem đơn hàng.
- Lưu trữ SQLite 1 file (`data.sqlite`).

## Deploy nhanh
- Render/Railway: tạo dịch vụ Node, thêm biến môi trường `PORT` nếu cần.
- Cần persistent disk nếu muốn giữ `data.sqlite`.
