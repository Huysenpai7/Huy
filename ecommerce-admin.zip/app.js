
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const ejs = require('ejs');
const { db, ensureSchema, createDefaultAdmin } = require('./db');

const app = express();

const PORT = process.env.PORT || 3000;
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: 'please-change-this-secret',
  resave: false,
  saveUninitialized: false
}));

// Simple layout wrapper: always render view into views/layout.ejs as body
function renderWithLayout(res, view, params={}) {
  const viewPath = path.join(__dirname, 'views', `${view}.ejs`);
  const layoutPath = path.join(__dirname, 'views', 'layout.ejs');
  const body = ejs.render(fs.readFileSync(viewPath, 'utf8'), params, { filename: viewPath });
  const html = ejs.render(fs.readFileSync(layoutPath, 'utf8'), { ...(params || {}), body }, { filename: layoutPath });
  res.send(html);
}

// Multer for image uploads
const uploadDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = (file.originalname.split('.').pop() || 'jpg').toLowerCase();
    cb(null, unique + '.' + ext);
  }
});
const upload = multer({ storage });

function isAdmin(req) { return !!req.session.adminId; }
function requireAdmin(req, res, next) { if (!isAdmin(req)) return res.redirect('/admin/login'); next(); }

ensureSchema().then(async () => { await createDefaultAdmin(ADMIN_USERNAME, ADMIN_PASSWORD); })
  .catch(err => { console.error('DB init error:', err); process.exit(1); });

// ----------------- PUBLIC SHOP -----------------
app.get('/', (req, res) => {
  db.all('SELECT * FROM products WHERE active = 1 ORDER BY created_at DESC', [], (err, rows) => {
    if (err) return res.status(500).send('DB error');
    renderWithLayout(res, 'shop/index', { products: rows, cart: req.session.cart || [] });
  });
});

app.get('/product/:id', (req, res) => {
  db.get('SELECT * FROM products WHERE id = ?', [req.params.id], (err, row) => {
    if (err || !row) return res.status(404).send('Product not found');
    renderWithLayout(res, 'shop/product', { product: row, cart: req.session.cart || [] });
  });
});

app.get('/cart', (req, res) => {
  const cart = req.session.cart || [];
  if (cart.length === 0) return renderWithLayout(res, 'shop/cart', { items: [], total: 0 });
  const ids = cart.map(i => i.productId);
  const placeholders = ids.map(() => '?').join(',');
  db.all(`SELECT * FROM products WHERE id IN (${placeholders})`, ids, (err, rows) => {
    if (err) return res.status(500).send('DB error');
    const items = cart.map(item => {
      const product = rows.find(r => r.id === item.productId);
      return { product, qty: item.qty, subtotal: product ? product.price * item.qty : 0 };
    }).filter(x => x.product);
    const total = items.reduce((s, it) => s + it.subtotal, 0);
    renderWithLayout(res, 'shop/cart', { items, total });
  });
});

app.post('/cart/add', (req, res) => {
  const { productId, qty } = req.body;
  const q = Math.max(1, parseInt(qty || '1', 10));
  if (!req.session.cart) req.session.cart = [];
  const idx = req.session.cart.findIndex(i => i.productId == productId);
  if (idx >= 0) req.session.cart[idx].qty += q;
  else req.session.cart.push({ productId: parseInt(productId, 10), qty: q });
  res.redirect('/cart');
});

app.post('/cart/update', (req, res) => {
  const { quantities = {} } = req.body;
  const cart = [];
  for (const [pid, qty] of Object.entries(quantities)) {
    const q = Math.max(0, parseInt(qty, 10) || 0);
    if (q > 0) cart.push({ productId: parseInt(pid, 10), qty: q });
  }
  req.session.cart = cart;
  res.redirect('/cart');
});

app.post('/checkout', (req, res) => {
  const { name, email, address } = req.body;
  const cart = req.session.cart || [];
  if (!cart.length) return res.redirect('/cart');
  const ids = cart.map(i => i.productId);
  const placeholders = ids.map(() => '?').join(',');
  db.all(`SELECT id, price FROM products WHERE id IN (${placeholders})`, ids, (err, rows) => {
    if (err) return res.status(500).send('DB error');
    const priceMap = Object.fromEntries(rows.map(r => [r.id, r.price]));
    const total = cart.reduce((s, it) => s + (priceMap[it.productId] || 0) * it.qty, 0);
    db.run('INSERT INTO orders (name, email, address, total) VALUES (?,?,?,?)',
      [name, email, address, total],
      function(err2) {
        if (err2) return res.status(500).send('DB error');
        const orderId = this.lastID;
        const stmt = db.prepare('INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?,?,?,?)');
        cart.forEach(it => stmt.run([orderId, it.productId, it.qty, priceMap[it.productId] || 0]));
        stmt.finalize();
        req.session.cart = [];
        renderWithLayout(res, 'shop/thanks', { orderId, total });
      });
  });
});

// ----------------- ADMIN -----------------
app.get('/admin/login', (req, res) => {
  if (isAdmin(req)) return res.redirect('/admin');
  renderWithLayout(res, 'admin/login', { error: null });
});

app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM admins WHERE username = ?', [username], (err, admin) => {
    if (err || !admin) return renderWithLayout(res, 'admin/login', { error: 'Sai tài khoản hoặc mật khẩu' });
    bcrypt.compare(password, admin.password_hash).then(match => {
      if (!match) return renderWithLayout(res, 'admin/login', { error: 'Sai tài khoản hoặc mật khẩu' });
      req.session.adminId = admin.id;
      res.redirect('/admin');
    });
  });
});

app.get('/admin/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

app.get('/admin', requireAdmin, (req, res) => {
  db.get('SELECT COUNT(*) AS pcount FROM products', [], (err1, p) => {
    db.get('SELECT COUNT(*) AS ocount FROM orders', [], (err2, o) => {
      renderWithLayout(res, 'admin/dashboard', { pcount: p?.pcount || 0, ocount: o?.ocount || 0 });
    });
  });
});

app.get('/admin/products', requireAdmin, (req, res) => {
  db.all('SELECT * FROM products ORDER BY created_at DESC', [], (err, rows) => {
    renderWithLayout(res, 'admin/products', { products: rows || [] });
  });
});

app.get('/admin/products/new', requireAdmin, (req, res) => {
  renderWithLayout(res, 'admin/product_form', { product: null });
});

app.get('/admin/products/:id/edit', requireAdmin, (req, res) => {
  db.get('SELECT * FROM products WHERE id = ?', [req.params.id], (err, row) => {
    if (!row) return res.redirect('/admin/products');
    renderWithLayout(res, 'admin/product_form', { product: row });
  });
});

app.post('/admin/products', requireAdmin, upload.single('image'), (req, res) => {
  const { name, description, price, active } = req.body;
  const imgPath = req.file ? '/uploads/' + req.file.filename : '';
  db.run('INSERT INTO products (name, description, price, image, active) VALUES (?,?,?,?,?)',
    [name, description, parseFloat(price || '0'), imgPath, active ? 1 : 0],
    () => res.redirect('/admin/products'));
});

app.post('/admin/products/:id', requireAdmin, upload.single('image'), (req, res) => {
  const { name, description, price, active } = req.body;
  if (req.file) {
    const imgPath = '/uploads/' + req.file.filename;
    db.run('UPDATE products SET name=?, description=?, price=?, image=?, active=? WHERE id=?',
      [name, description, parseFloat(price || '0'), imgPath, active ? 1 : 0, req.params.id],
      () => res.redirect('/admin/products'));
  } else {
    db.run('UPDATE products SET name=?, description=?, price=?, active=? WHERE id=?',
      [name, description, parseFloat(price || '0'), active ? 1 : 0, req.params.id],
      () => res.redirect('/admin/products'));
  }
});

app.post('/admin/products/:id/delete', requireAdmin, (req, res) => {
  db.run('DELETE FROM products WHERE id=?', [req.params.id], () => res.redirect('/admin/products'));
});

app.get('/admin/orders', requireAdmin, (req, res) => {
  db.all('SELECT * FROM orders ORDER BY created_at DESC', [], (err, rows) => {
    renderWithLayout(res, 'admin/orders', { orders: rows || [] });
  });
});

app.get('/admin/orders/:id', requireAdmin, (req, res) => {
  db.get('SELECT * FROM orders WHERE id=?', [req.params.id], (err, order) => {
    if (!order) return res.redirect('/admin/orders');
    db.all('SELECT oi.*, p.name FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE order_id=?',
      [order.id], (err2, items) => {
        renderWithLayout(res, 'admin/order_detail', { order, items: items || [] });
      });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
